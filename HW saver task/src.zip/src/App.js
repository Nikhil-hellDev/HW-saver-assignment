import React from 'react';

import AllRouter from './component/AllRouter'


function App() {
  return (
    <div>
       <AllRouter/>
      
    </div>
   
  );
}

export default App;
